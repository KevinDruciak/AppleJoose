README for hw3 OOSE assignment
