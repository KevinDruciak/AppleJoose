# MyBooksApp

This is a simple application we build during lectures in fall 2020 OOSE class together to practice with various concepts and technologies. This 
is a web app conforming to Client-Server Architecture where user(s) can store/access their favorite books and authors. The app
will store data in a database and its backend functionalities are implemented as RESTful API end-points.
