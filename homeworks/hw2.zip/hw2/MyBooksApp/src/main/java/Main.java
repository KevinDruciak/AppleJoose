import model.Author;
import org.sql2o.Sql2o;
import persistence.Sql2oAuthorDao;
import persistence.Sql2oBookDao;

public class Main {

    public static void main(String[] args)  {


    }
}
