package exception;

public class DaoException extends RuntimeException {
    public DaoException() {
        super("DaoException");
    }
}
